const SERVICE_ACCOUNT_CREDENTIALS = {
  "type": "service_account",
  "project_id": "civil-tempo-479514-t9",
  "private_key_id": "5aace65c588c5ed7bf78fc915485a6f9d83899dd",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCXRT0jITy5beup\n1GIPNbAq4zbGCdBlt1+eVQkVPVCVjIdXIJ2VTgiSR4clfNNzJXWcQ+OQqFJYbt1m\nIHmx41RJUDAyTJcOYcm3bO6jdBHGzL3w3/kXEP6uupRAtfKYUHwOWF+Yw9s/qSL6\nu71ZKZuxYv/oVBzFSeDW5OCkNZsCrUw+OCYfyFUSrEcWXHCzEweqQnW0mDiViz4V\nZNUMfCeVN7BleoF19w2VYnE9YCWPV6j65ApoS1QMfABQxeOuMtKKvOhGg2Ilbj6l\nzLlRvU3Lwm8UiVoJapV7+FCpXhversZYdIyZhbMYz2spj6+rEedyCSoy/kUHOXin\nMMRmn0tjAgMBAAECggEAEyp3Ig3Sg039h2F84R90yCJMrM/Ogyy2JTnx8ip4HNKW\nzT+5J5Mg++OrKGFF6zdqTNe/K/Nfp4u4anmf4Z2DbtyFlsHke7KBG8fl/ni0zeLg\nB/ZguX7yPdIu+Xn0GD9OUIT668CY9VppL6p8xaDDdLit4tJRaN/A6IlMOxH9p1t6\np/Fm2Y+FsIZ1Fy46QHPtkrNUvz/E+96FlLWHLJzqoMTNr4i8DNQ6G2sUKMtOp+Ig\nQkX7KMygyg3xbpGmOxM5/TDQ+a4LvjDGycXvtp7nUyXj5fNBTP7E9Mo9j+8EVVI8\nQOFW1pZScrRUbwuZv/NagIM7D0FA0qWDAd0vWzNU1QKBgQDTg3dOxt8Cm9fgQtWz\nccrgsNTA3DCv0Gj+7P7y45qWchTV4HrDs3WOFWrLx0sxVVPhVRDSM99KMZKde4pR\niBGhzLo5rZlkhdFsc4LKZ96Ohpkq7QfRdAojCjbI48B3gprfWTCJ6ig7xuXVJIwa\n2d91CAUU3UolX1OT22aI/eDkZwKBgQC3FhoWCsKnMzLgtbwANogrs+ym8DhrE30u\ns+L7NHxnsg1tigbcR6dYI/LJxJepMe2zcQk8hx2acaZMskS/xV6t+k4mT9CG9yuU\n71lhMzJQhp9z+iZYT5MaVE6Rhj3UEx2UrS1MFDjC7j6ki2cL4etagmFT2/XSHtyz\nmDhh174jpQKBgCPKsVvBR2eXm5Y1eRgef2g6RCZGnG6D4+CPlizf2v7uWxw+GkgX\njCL4+NN27ABzIfiVfn0zjetuLBM+Ho/haKpqjHDKMZTTGDcz7MP3g6+2kyCyb4pA\nCp8XUWH5OE6A6Vg2LYKI/znuVGIXByZcC/Yv3zxCnhNo6CmzDMzNuUqtAoGAX4Lz\nNt6EL4+BEkMcgYvxO8NQSMJ23D09h/imB+CYqcv0P1nLPG1Q+qU+Sk35xHVciMkG\nRYJDSkfRtp8lSFnhi6dRz6DBqzcUkEzQ9ukrbWDdnDY6fMV+ezTSDA7ZAGK8gsxZ\nHiBKgD6jhVmH92XzTrNHrOTJ98TL5BEcEMbo1VUCgYEApXB1cz9m/UCQ9pZrN0ys\n4DsId1djfDG9G1ZWCanGCX4ljwDhomzY8olNdYka6Shin4ck7/ohlCRdXcAeTWa1\ntweyydN8G+BiJWWoPeF8E+T22STmsldsH1QJexEVMIyFWY/xzZS8vah/LqoNAVmN\nS/RC1ONqV55RPyfOCCuVVtE=\n-----END PRIVATE KEY-----\n",
  "client_email": "google-sheet-reader@civil-tempo-479514-t9.iam.gserviceaccount.com",
  "client_id": "103299930263392282398",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/google-sheet-reader%40civil-tempo-479514-t9.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};


if (typeof module !== 'undefined' && module.exports) {
  module.exports = SERVICE_ACCOUNT_CREDENTIALS;
}

if (typeof window !== 'undefined') {
  window.SERVICE_ACCOUNT_CREDENTIALS = SERVICE_ACCOUNT_CREDENTIALS;
}